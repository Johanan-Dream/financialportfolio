package javaproject.portfolio.DTO;

public class BankType {
	private int banktype_idx;
	private String bank_type;
	
	public int getBanktype_idx() {
		return banktype_idx;
	}
	public void setBanktype_idx(int banktype_idx) {
		this.banktype_idx = banktype_idx;
	}
	public String getBank_type() {
		return bank_type;
	}
	public void setBank_type(String bank_type) {
		this.bank_type = bank_type;
	}

}
