package javaproject.portfolio.domain;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class CategoryMenu extends JPanel{
	
	public CategoryMenu() {
		setPreferredSize(new Dimension(30,30));
		setBackground(new Color(255,0,0,0));
	}
}
